@extends('header/menu')
@section('title', 'Contato')

@section('conteudo')
@component('components.formularioContato')
@endcomponent
@endsection