
<?php $__env->startSection('title', 'Contato'); ?>

<?php $__env->startSection('conteudo'); ?>
<?php $__env->startComponent('components.formularioContato'); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('header/menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuário\Downloads\prova2Php\prova2Php\resources\views/contato.blade.php ENDPATH**/ ?>