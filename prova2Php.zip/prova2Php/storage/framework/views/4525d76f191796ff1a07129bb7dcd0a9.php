
<?php $__env->startSection('conteudo'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action = <?php echo e(route('site.contato')); ?> method="post">
        <input name="nome" type="text" placeholder="Nome">Nome</input>
        <br>
        <input name="email" type="text" placeholder="E-mail">E-mail</input>
        <br>
        <select name="assunto">
            <option value="1">Dúvida</option>
            <option value="2">Elogio</option>
            <option value="3">Sugestão</option>
            <option value="4">Suporte</option>
            <option value="5">Trabalhe Conosco</option>
            <option value="6">Outros</option>
        </select>
        <br>
        <textarea name="mensagem">Mensagem</textarea>
        <br>
        <button type="submit">Enviar</button>
    </form>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('header\menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuário\Downloads\prova2Php\prova2Php\resources\views/components/formulario.blade.php ENDPATH**/ ?>