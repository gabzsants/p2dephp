<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <title><?php echo $__env->yieldContent('titulo'); ?></title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>"> 
    </head>
 <body>
 <div class="topo">

            <div class="logo">
                <img width='60px' src=<?php echo e(asset ('img/logo.png')); ?>>
            </div>

            <div class='span-logo'> HelloDonut</div>

            <div class="menu">
              
            <ul>
            <li><a href="<?php echo e(route('site.paginaInicial')); ?>">Home</a>
            </li> 

            <ul>
            <li><a href="<?php echo e(route('site.sobreNos')); ?>">Sobre Nós</a>
            </li>

            <ul>
            <li><a href="<?php echo e(route('site.produtos')); ?>">Produtos</a>
            </li>
            </ul>

            <ul>
            <li><a href="<?php echo e(route('site.contato')); ?>">Contato</a>
            </li>
            </ul>

            <ul>
                <li><a href="<?php echo e(route('site.cadastrarDonut')); ?>">Cadastrar Donut</a>
                </li>
                </ul>

            </div>
        </div>

        <main class='main'>
                <?php echo $__env->yieldContent('conteudo'); ?>
        </main>
</body>
</html>
<?php /**PATH C:\Users\Usuário\Downloads\prova2Php\prova2Php\resources\views/header\menu.blade.php ENDPATH**/ ?>