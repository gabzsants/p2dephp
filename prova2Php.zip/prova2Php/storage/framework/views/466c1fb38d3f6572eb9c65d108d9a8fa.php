
<?php $__env->startSection('titulo', 'Página Inicial'); ?>
<?php $__env->startSection('conteudo'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title></title>
</head>
<body>
    


</body>
</html>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('header\menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuário\Downloads\prova2Php\prova2Php\resources\views/paginainicial.blade.php ENDPATH**/ ?>