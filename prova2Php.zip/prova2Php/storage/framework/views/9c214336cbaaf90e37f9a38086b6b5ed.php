

<?php $__env->startSection('conteudo'); ?>
<h3>A página que você tentou acessar não existe ://</h3>
<img src=<?php echo e(asset ('img/imgfallback.jpg')); ?>>
<h3><a href="<?php echo e(route('site.paginaInicial')); ?>">Clique aqui</a> para voltar a página inicial.</h3>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('header\menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuário\Downloads\prova2Php\prova2Php\resources\views/fallback.blade.php ENDPATH**/ ?>