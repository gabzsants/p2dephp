<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class contato extends Controller
{
    public function contato(){
        return view('contato');
    }

}
