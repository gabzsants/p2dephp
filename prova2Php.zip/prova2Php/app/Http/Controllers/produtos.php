<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class produtos extends Controller
{
    public function produtos(){
        return view('produtos');
    }

}
