<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class sobreNos extends Controller
{
    public function sobreNos(){
        return view('sobreNos');
    }
}
