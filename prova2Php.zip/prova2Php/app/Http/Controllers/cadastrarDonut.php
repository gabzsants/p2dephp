<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class cadastrarDonut extends Controller
{
    public function cadastrarDonut(){
        return view('cadastrarDonut');
    }

}
